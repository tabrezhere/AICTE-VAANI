﻿using Azure;
using Azure.AI.FormRecognizer.DocumentAnalysis;
using Microsoft.AspNetCore.Components;
namespace Blazor_KBN_PDF.Components.Pages
{
    public partial class FormRecognizer : ComponentBase
    {
        private AnalyzeResult? result;
        private bool isLoading = false;

        private async Task AnalyzeDocument()
        {
            isLoading = true;

            string endpoint = Configuration["AzureFormRecognizer:Endpoint"];
            string key = Configuration["AzureFormRecognizer:Key"];

            var credential = new AzureKeyCredential(key);
            var client = new DocumentAnalysisClient(new Uri(endpoint), credential);

            Uri fileUri = new Uri("https://raw.githubusercontent.com/Azure-Samples/cognitive-services-REST-api-samples/master/curl/form-recognizer/sample-layout.pdf");

            var operation = await client.AnalyzeDocumentFromUriAsync(WaitUntil.Completed, "prebuilt-document", fileUri);
            result = operation.Value;

            isLoading = false;
            StateHasChanged();
        }
    }
}
