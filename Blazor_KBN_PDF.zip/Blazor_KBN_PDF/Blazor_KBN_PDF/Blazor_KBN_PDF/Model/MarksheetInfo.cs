﻿namespace Blazor_KBN_PDF.Model
{
    public class MarksheetInfo
    {
        public string RollNo { get; set; } = "";
        public string StudentName { get; set; } = "";
        public string CollegeName { get; set; } = "";
        public string GrandTotal { get; set; } = "";
        public string Result { get; set; } = "";
    }
}
