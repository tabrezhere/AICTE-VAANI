using Blazor_KBN_PDF.Components;
using Blazor_KBN_PDF.Services;
using BlazorPdfExtractor.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// Add services to the container.
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();
builder.Services.AddSingleton<PdfService>();
builder.Services.AddSingleton<FormRecognizerService>();


// Register OpenAIService with configuration
var openAIConfig = builder.Configuration.GetSection("AzureOpenAI");
builder.Services.AddSingleton(provider =>
    new OpenAIService(
        openAIConfig["Endpoint"],
        openAIConfig["Key"],
        openAIConfig["DeploymentName"]
    )
);


var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();


app.UseAntiforgery();

app.MapStaticAssets();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
