﻿using System.Text.RegularExpressions;
using Azure;
using Azure.AI.FormRecognizer.DocumentAnalysis;
using Blazor_KBN_PDF.Model;
namespace Blazor_KBN_PDF.Services
{

    public class FormRecognizerService
    {
        

        public async Task<MarksheetInfo> AnalyzeDocumentAsync(Stream fileStream, string fileName)
        {

            string endpoint = "";
            string key = "";
            AzureKeyCredential credential = new AzureKeyCredential(key);
            DocumentAnalysisClient client = new DocumentAnalysisClient(new Uri(endpoint), credential);

            try
            {
                // Reset position to start
                if (fileStream.CanSeek)
                    fileStream.Position = 0;

                var operation = await client.AnalyzeDocumentAsync(
                    WaitUntil.Completed, "prebuilt-read", fileStream);

                var text = operation.Value.Content;
                // Extract values using regex
                var info = new MarksheetInfo
                {
                    RollNo = Regex.Match(text, @"ROLL NO\s*:?\s*([0-9]+)").Groups[1].Value.Trim(),
                    StudentName = Regex.Match(text, @"STUDENT'S NAME\s*:?\s*([A-Z\s]+?)(?=\s*FATHER'S NAME)").Groups[1].Value.Trim(),
                    CollegeName = Regex.Match(text, @"COLLEGE/CENTRE\s*:?\s*(.*)").Groups[1].Value.Trim(),
                    GrandTotal = Regex.Match(text, @"Grand Total.*?\)\s*([0-9]+)").Groups[1].Value,
                    Result = Regex.Match(text, @"Result\s*:?\s*([A-Z]+)").Groups[1].Value
                };

                return info;
            }
            catch
            {
                return null;
            }

            

            
        }
    }

}
