﻿using OpenAI.Chat;
using Azure;
using Azure.AI.OpenAI;

namespace BlazorPdfExtractor.Services
{
    public class OpenAIService
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiKey;
        private readonly string _endpoint;
        private readonly string _deploymentName;

        public OpenAIService(string endpoint, string key, string deploymentName)
        {
            _httpClient = new HttpClient();
            _apiKey = key;
            _endpoint = endpoint;
            _deploymentName = deploymentName;

            // Set up the API key in the header
            _httpClient.DefaultRequestHeaders.Add("api-key", _apiKey);
        }

        public async Task<string> GetSummary(string text, string language = "English")
        {
            try
            {
                string  contentText;
                var endpoint = new Uri("");
                var deploymentName = "";
                var apiKey = "";

                AzureOpenAIClient azureClient = new(
                    endpoint,
                    new AzureKeyCredential(apiKey));
                ChatClient chatClient = azureClient.GetChatClient(deploymentName);
                var requestOptions = new ChatCompletionOptions()
                {
                    MaxOutputTokenCount = 4096,
                    Temperature = 1.0f,
                    TopP = 1.0f,

                };


                List<ChatMessage> messages = new List<ChatMessage>()
                    {
                        new SystemChatMessage("You are a helpful assistant to provide the summary in point for the given input."),
                        new UserChatMessage(text),
                    };

                var response = chatClient.CompleteChat(messages, requestOptions);
                System.Console.WriteLine(response.Value.Content[0].Text);

                return contentText = response.Value.Content[0].Text;
                
            }
            catch (Exception ex)
            {
                return "Error generating summary. Please check your Azure OpenAI configuration.";
            }
        }
    }
}