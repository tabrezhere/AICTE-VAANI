﻿using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas.Parser;
using iText.Kernel.Pdf.Canvas.Parser.Listener;
using System.Text;
using System.IO;

namespace BlazorPdfExtractor.Services
{
    public class PdfService
    {
        public async Task<string> ExtractTextFromPdf(Stream pdfStream)
        {
            // Copy the stream to a MemoryStream to avoid synchronous read issues
            using (var memoryStream = new MemoryStream())
            {
                await pdfStream.CopyToAsync(memoryStream);
                memoryStream.Position = 0; // Reset position for reading

                var text = new StringBuilder();

                using (var pdfReader = new PdfReader(memoryStream))
                using (var pdfDocument = new PdfDocument(pdfReader))
                {
                    for (int i = 1; i <= pdfDocument.GetNumberOfPages(); i++)
                    {
                        var strategy = new SimpleTextExtractionStrategy();
                        var pageText = PdfTextExtractor.GetTextFromPage(pdfDocument.GetPage(i), strategy);
                        text.AppendLine(pageText);
                    }
                }

                return text.ToString();
            }
        }

        public async Task<List<string>> ExtractImagesFromPdf(Stream pdfStream)
        {
            // Copy the stream to a MemoryStream to avoid synchronous read issues
            using (var memoryStream = new MemoryStream())
            {
                await pdfStream.CopyToAsync(memoryStream);
                memoryStream.Position = 0; // Reset position for reading

                var imageList = new List<string>();
                // This is a simplified implementation - actual image extraction would be more complex
                // For demonstration, we'll return placeholder image data

                // In a real implementation, you would:
                // 1. Extract images from the PDF using iText
                // 2. Convert them to base64 strings
                // 3. Add to the imageList

                // Placeholder for demo purposes
                imageList.Add("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==");

                return imageList;
            }
        }
    }
}